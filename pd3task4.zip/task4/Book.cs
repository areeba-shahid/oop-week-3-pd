﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task4.BL
{
    internal class Book
    {
        public string Title;
        public string Author;
        public int PublicationYear;
        public float Price;
        public int QualityInStock;

        public Book(string title, string author, int publicationYear, float price, int qualityInStock) 
        {
            Title = title;
            Author = author;
            PublicationYear = publicationYear;
            Price = price;
            QualityInStock = qualityInStock;
        }

        public string getTitle()
        {
            return "Title: {Title} ";
        }
        public string getAuthor()
        {
            return "Author: {Author} ";
        }
        public string getPublicationYear() 
        {
            return "Publication Year: {PublicationYear} ";
        }
        public string getPrice() 
        {
            return "Price: {Price} ";
        }
        public void sellCopies(int numberOfCopies)
        {
            if ( QualityInStock >= numberOfCopies ) 
            {
                QualityInStock = QualityInStock - numberOfCopies;
                Console.WriteLine("{numberOfCopies} copies of {Title} sold successfully.");
            }
            else
            {
                Console.WriteLine("Error! Not enough copies of {Title} in stock. ");
            }

        }
        public void restock(int additionalCopies)
        {
            QualityInStock += additionalCopies;
            Console.WriteLine("{additionalCopies} copies of {Title} restocked successfully.");
        }
        public string bookDetails()
        {
            return "{getTitle()} \n {getAuthor()} \n {getPublicationYear()} \n {getPrice()} \n Quality In Stock: {QualityInStock} ";
        }
    }
}
