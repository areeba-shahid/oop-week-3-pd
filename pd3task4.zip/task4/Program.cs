﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using task4.BL;

namespace task4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Book> bookList = new List<Book>();

            Book book1 = new Book("Pride & Prejudice", "Jane Austen", 1813, 19.99F, 10);
            Book book2 = new Book("Hamlet", "William Shakespeare", 1603, 15.50F, 20);
            Book book3 = new Book("War & Peace", "Leo Tolstoy", 1869, 25.99F, 15);

            bookList.Add(book1);
            bookList.Add(book2);
            bookList.Add(book3);

            int choice = 0;
            while (choice != 7)
            {

                Console.WriteLine("Menu Options:");
                Console.WriteLine("1. Add Book");
                Console.WriteLine("2. View All the Books information");
                Console.WriteLine("3. Get the Author details of a specific book");
                Console.WriteLine("4. Sell Copies of a Specific Book");
                Console.WriteLine("5. Restock a Specific Book");
                Console.WriteLine("6. See the count of the Books present in your bookList");
                Console.WriteLine("7. Exit");
                Console.Write("Enter your choice: ");
                choice = int.Parse(Console.ReadLine());

                if (choice == 1)
                {
                    Console.WriteLine("Enter title: ");
                    string title = Console.ReadLine();
                    Console.WriteLine("Enter author: ");
                    string author = Console.ReadLine();
                    Console.WriteLine("Enter publication Year: ");
                    int publicationYear = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter price");
                    float price = float.Parse(Console.ReadLine());
                    Console.WriteLine("Enter quality in stock: ");
                    int qualityInStock = int.Parse(Console.ReadLine());

                    Book newBook = new Book(title, author, publicationYear, price, qualityInStock);
                    bookList.Add(newBook);

                    Console.WriteLine("Book Added Successfully.");
                    Console.ReadLine();
                    Console.Clear();
                }
                if (choice == 2)
                {
                    foreach (Book book in bookList)
                    {
                        Console.WriteLine($"Title: {book.Title}\tAuthor: {book.Author}\t Publication Year: {book.PublicationYear}\t Price: {book.Price}\t Quality in Stock: {book.QualityInStock}");
                    }
                    Console.ReadLine();
                    Console.Clear();
                }
                if (choice == 3)
                {
                    Console.WriteLine("Enter the Title of the book: ");
                    string title = Console.ReadLine();

                    foreach (Book book in bookList)
                    {
                        if (title == book.Title)
                        {
                            Console.WriteLine($"Author of {book.Title} is {book.Author}.");
                        }

                        Console.WriteLine("Book not found...");
                    }
                    Console.ReadLine();
                    Console.Clear();
                }
                if (choice == 4)
                {
                    Console.WriteLine("Enter the Title of the book: ");
                    string title = Console.ReadLine();
                    Console.WriteLine("Enter the number of copies you want to sell: ");
                    int numberOfCopies = int.Parse(Console.ReadLine());
                    foreach (Book book in bookList)
                    {
                        if (title == book.Title)
                        {
                            book.sellCopies(numberOfCopies);
                            break;
                        }
                        Console.WriteLine("Book not found...");

                    }
                    Console.ReadLine();
                    Console.Clear();
                }
                if (choice == 7)
                {
                    Console.WriteLine("Exiting...");
                    break;
                }
                if (choice > 7)
                {
                    Console.WriteLine("Invalid option! Please choose an option between 1 & 7...");
                    Console.ReadLine();
                    Console.Clear();
                }

            }
        }
    }
}