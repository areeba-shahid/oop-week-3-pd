﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using task3.BL;

namespace task3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Shiritori game = new Shiritori();

            // Example gameplay
            Console.WriteLine(game.Play("word"));     // valid
            Console.WriteLine(game.Play("dowry"));    // valid
            Console.WriteLine(game.Play("yodel"));    // valid
            Console.WriteLine(game.Play("leader"));   // valid
            Console.WriteLine(game.Play("righteous"));// valid
            Console.WriteLine(game.Play("serpent"));  // valid

            // Trying to play an invalid word
            Console.WriteLine(game.Play("motive"));   // game over
            Console.WriteLine(game.GameOver);         // true

            // Restarting the game
            Console.WriteLine(game.Restart());        // game restarted
            Console.WriteLine(game.Play("hive"));     // valid
        }
    }
    }
