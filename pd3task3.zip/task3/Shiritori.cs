﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task3.BL
{
    internal class Shiritori
    {

        private List<string> words;
        private bool game_over;

        public Shiritori()
        {
            words = new List<string>();
            game_over = false;
        }

        public List<string> Words
        {
            get { return words; }
        }

        public bool GameOver
        {
            get { return game_over; }
        }

        public string Play(string word)
        {
            if (game_over)
            {
                return "game over";
            }

            if (words.Count > 0 && word[0] != words[words.Count - 1][words[words.Count - 1].Length - 1])
            {
                game_over = true;
                return "game over";
            }

            if (words.Contains(word))
            {
                game_over = true;
                return "game over";
            }

            words.Add(word);
            return "valid";
        }

        public string Restart()
        {
            words.Clear();
            game_over = false;
            return "game restarted";
        }


    }
}
