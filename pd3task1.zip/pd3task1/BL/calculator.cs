﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace pd3task1.BL
{
    class calculator
    {

        public float num1;
        public float num2;
        public calculator()
        {
            num1 = 10;
            num2 = 10;
        }
         

        public float sum(float num1 , float num2)
        {
            Console.Clear();
            return num1 + num2;
        }
        public float subtract(float num1 , float num2)
        {
            Console.Clear();

            return num1 - num2;


        }
        public float multiply(float num1 , float num2)
        {
            Console.Clear();
            return num1 * num2;
        }
        public float divide(float num1 , float num2)
        {
            Console.Clear();
            if (num1 == 0 || num2 == 0)
            {
                return 000;
            }

            else
            {
                return num1 / num2;
            }

        }
        public float modulo(float num1 ,float num2)
        {
            Console.Clear();
            return num1 % num2;
        }

        public calculator assignAttribute(calculator obj , float num1 , float num2)
        {
            Console.Clear();
            obj.num1 = num1;
            obj.num2 = num2;
            return obj;
        }
    }
}
