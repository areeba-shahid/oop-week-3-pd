﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using pd3task1.BL;

namespace pd3task1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            calculator obj = new calculator();
            float opt = 0;
            while (opt != 8)
            {
                float num1;
                float num2;
                
                opt = menu();
                if (opt == 1)
                {

                    createobject();

                }
                if (opt == 2)
                {
                    Console.WriteLine("Enter value of num 1");
                    num1 = float.Parse(Console.ReadLine());
                    Console.WriteLine("Enter value of num 2");
                    num2 = float.Parse(Console.ReadLine());
                    obj.assignAttribute(obj, num1, num2);
                }
                if (opt == 3)
                {

                    float add = obj.sum(obj.num1, obj.num2);
                    Console.WriteLine("answer is {0}", add);
                }
                if (opt == 4)
                {
                    float minus = obj.subtract(obj.num1, obj.num2);
                    Console.WriteLine("answer is {0}", minus);
                }
                if (opt == 5)
                {
                    float mul = obj.multiply(obj.num1, obj.num2);
                    Console.WriteLine("answer is {0}", mul);
                }
                if (opt == 6)
                {
                    float div = obj.divide(obj.num1, obj.num2);
                    Console.WriteLine("answer is {0}", div);
                }
                if (opt == 7)
                {
                    float mod = obj.modulo(obj.num1, obj.num2);
                    Console.WriteLine("answer is {0}", mod);
                }
                if (opt == 9)
                {
                    double sr = obj.sqroot(obj.num1);
                    Console.WriteLine("answer is {0}", sr);
                }
                if (opt == 10)
                {
                   double expo = obj.exp(obj.num1);
                    Console.WriteLine("answer is {0}",expo );
                }
               
                if (opt == 11)
                {
                    double logg= obj.log(obj.num1);
                    Console.WriteLine("answer is {0}", logg);
                }
                if (opt == 12)
                {
                    double sinn = obj.sine(obj.num1);
                    Console.WriteLine("answer is {0}", sinn);
                }
                if (opt == 13)
                {
                    double coss = obj.cose(obj.num1);
                    Console.WriteLine("answer is {0}", coss);
                }
                if (opt == 14)
                {
                    double tann = obj.tan(obj.num1);
                    Console.WriteLine("answer is {0}", tann);
                }


            }

        }
        static float menu()
        {

            Console.WriteLine(" 1 - CReate single object of class");
            Console.WriteLine(" 2 - Assign value to attributes");
            Console.WriteLine(" 3 - To sum");
            Console.WriteLine(" 4 - To subtract");
            Console.WriteLine(" 5 - To multiply");
            Console.WriteLine(" 6 - To divide");
            Console.WriteLine(" 7 - To modulo");
            Console.WriteLine(" 9 - To find sq root");
            Console.WriteLine(" 10 - To find exponent");
            Console.WriteLine(" 11 - To find log");
            Console.WriteLine(" 12 - to find sine");
            Console.WriteLine(" 13 - to find cos");
            Console.WriteLine(" 14 - to find tangent");
            Console.WriteLine(" 8 - Exit");
            Console.WriteLine("Enter option : ");
            float op = float.Parse(Console.ReadLine());
            return op;
        }
        static void createobject()
        {
            Console.Clear();
            Console.WriteLine("object has beem created");
        }




    }
}

