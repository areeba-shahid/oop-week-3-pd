﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;


namespace pd3task1.BL
{
    class calculator
    {

        public float num1;
        public float num2;
        public calculator()
        {
            num1 = 10;
            num2 = 10;
        }


        public float sum(float num1, float num2)
        {
            Console.Clear();
            return num1 + num2;
        }
        public float subtract(float num1, float num2)
        {
            Console.Clear();

            return num1 - num2;


        }
        public float multiply(float num1, float num2)
        {
            Console.Clear();
            return num1 * num2;
        }
        public float divide(float num1, float num2)
        {
            Console.Clear();
            if (num1 == 0 || num2 == 0)
            {
                return 000;
            }

            else
            {
                return num1 / num2;
            }

        }
        public float modulo(float num1, float num2)
        {
            Console.Clear();
            return num1 % num2;
        }

        public calculator assignAttribute(calculator obj, float num1, float num2)
        {
            Console.Clear();
            obj.num1 = num1;
            obj.num2 = num2;
            return obj;
        }

        public double sqroot(float num1)
        {
            Console.Clear();
            return Math.Sqrt(num1);
        }
        public double exp(float num1)
        {
            Console.Clear();
            return Math.Exp(num1);
        }
        public double log(float num1)
        {
            Console.Clear();
            return Math.Log(num1);
        }
        public double sine(float num1)
        {
            Console.Clear();
            return Math.Sin(num1);
        }
        public double cose(float num1)
        {
            Console.Clear();
            return Math.Cos(num1);
        }
        public double tan(float num1)
        {
            Console.Clear();
            return Math.Tan(num1);
        }

    }
}
